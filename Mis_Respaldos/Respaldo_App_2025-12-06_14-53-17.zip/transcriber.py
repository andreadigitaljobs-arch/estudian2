
import os
import subprocess
import google.generativeai as genai
import math
import glob

class Transcriber:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        # Updated to 2.0 Flash as per user availability
        self.model = genai.GenerativeModel('gemini-2.0-flash')

    def check_ffmpeg(self):
        """Checks if ffmpeg is available."""
        try:
            subprocess.run(["ffmpeg", "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def extract_audio(self, video_path, output_audio_path):
        """Extracts audio from video using ffmpeg."""
        if not self.check_ffmpeg():
            raise RuntimeError("ffmpeg not found. Please install ffmpeg and add it to your PATH.")
        
        # Extract audio to wav (pcm_s16le is standard)
        command = [
            "ffmpeg", "-i", video_path, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", "-y", output_audio_path
        ]
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return output_audio_path

    def chunk_audio(self, audio_path, chunk_length_sec=600): # 10 minutes default
        """Splits audio into chunks using ffmpeg (segment muxer)."""
        base_name, _ = os.path.splitext(audio_path)
        chunk_pattern = f"{base_name}_part%03d.wav"
        
        # Check duration first just to see if splitting is actually needed? 
        # Actually ffmpeg segment handles it gracefully (produces 1 file if short).
        # But to be consistent with previous logic, let's just run the segment command.
        
        command = [
            "ffmpeg", "-i", audio_path, 
            "-f", "segment", 
            "-segment_time", str(chunk_length_sec), 
            "-c", "copy", 
            "-reset_timestamps", "1",
            "-y", 
            chunk_pattern
        ]
        
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Find the generated files
        # The pattern has %03d, so glob looks like base_name + "_part*.wav"
        search_pattern = f"{base_name}_part*.wav"
        chunks = sorted(glob.glob(search_pattern))
        return chunks

    def transcribe_file(self, audio_file_path):
        """Uploads and transcribes a single file using Gemini API."""
        # Check standard file size limits if needed, but Gemini API usually handles direct upload via File API
        # actually for 1.5 Flash we should use the File API for audio.
        
        audio_file = genai.upload_file(audio_file_path)
        
        # Prompt in Spanish
        prompt = "Escucha este audio y proporciona una transcripción completa y precisa. El texto debe ser continuo y estar bien formateado."
        
        response = self.model.generate_content([prompt, audio_file])
        
        # Cleanup remote file? usually good practice but let's keep it simple first
        # audio_file.delete() # library might not have delete on object directly depending on version, check docs
        # genai.delete_file(audio_file.name)
        
        return response.text

    def process_video(self, video_path, progress_callback=None):
        """
        Orchestrates the entire flow for one video.
        progress_callback(stage, progress_0_to_1): update UI
        """
        video_name = os.path.basename(video_path)
        base_name, _ = os.path.splitext(video_name)
        
        if progress_callback: progress_callback(f"Extrayendo audio de {video_name}...", 0.1)
        
        temp_audio_path = f"temp_{base_name}.wav"
        try:
            self.extract_audio(video_path, temp_audio_path)
        except RuntimeError as e:
            return f"Error: {str(e)}"

        if progress_callback: progress_callback(f"Dividiendo audio de {video_name}...", 0.3)
        
        # Chunking (5-10 mins)
        # 600 segundos = 10 minutos
        chunks = self.chunk_audio(temp_audio_path, chunk_length_sec=600)
        
        full_transcript = []
        total_chunks = len(chunks)
        
        for i, chunk in enumerate(chunks):
            if progress_callback: progress_callback(f"Transcribiendo parte {i+1}/{total_chunks}...", 0.3 + (0.6 * (i/total_chunks)))
            text = self.transcribe_file(chunk)
            full_transcript.append(text)
            
            # Clean up chunk file if it's different from temp_audio_path
            if chunk != temp_audio_path:
                os.remove(chunk)
                
        # Clean up main temp audio
        if os.path.exists(temp_audio_path):
            os.remove(temp_audio_path)
            
        final_text = "\n\n".join(full_transcript)
        
        output_txt_path = f"{base_name}_transcripcion.txt"
        with open(output_txt_path, "w", encoding="utf-8") as f:
            f.write(final_text)
            
        if progress_callback: progress_callback("¡Listo!", 1.0)
        
        return output_txt_path

