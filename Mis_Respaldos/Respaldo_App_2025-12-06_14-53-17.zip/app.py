
import streamlit as st
import os
import glob
from transcriber import Transcriber
from study_assistant import StudyAssistant

st.set_page_config(page_title="Suite de Estudio IA", page_icon="🎓", layout="wide")

st.title("🎓 Suite de Estudio Inteligente")
st.markdown("Tu compañero integral para estudiar diplomados: Transcribe, Resume, Guía y Practica.")

# --- Custom CSS for Pro Design ---
st.markdown("""
<style>
    /* Import Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

    /* Global Settings */
    html, body, [class*="css"] {
        font-family: 'Poppins', sans-serif;
        font-size: 18px; /* Increased readability */
        color: #1A202C;
    }
    
    /* Headers - Pro Blue */
    h1, h2, h3 {
        color: #003366; /* Oxford Blue */
    }
    h1 { font-weight: 700; }
    
    /* Buttons */
    .stButton > button {
        background: linear-gradient(90deg, #0056b3 0%, #004494 100%);
        color: white;
        border: none;
        padding: 12px 28px;
        font-size: 18px;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        background: linear-gradient(90deg, #0069d9 0%, #0056b3 100%);
        color: white;
    }
    
    /* Input Fields */
    .stTextInput > div > div > input {
        border-radius: 8px;
        border: 1px solid #CBD5E0;
        padding: 10px;
    }
    
    /* Tabs styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: white;
        padding: 10px 0;
        border-radius: 10px;
    }

    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #F7FAFC;
        border-radius: 8px;
        color: #4A5568;
        font-size: 16px;
        font-weight: 500;
        border: 1px solid #E2E8F0;
        padding: 0 20px;
    }

    .stTabs [aria-selected="true"] {
        background-color: #EBF8FF;
        color: #2B6CB0; /* Blue text for selected */
        border: 1px solid #BEE3F8;
        border-bottom: 2px solid #3182CE;
    }
    
    /* Cards/Containers */
    .element-container {
        margin-bottom: 1rem;
    }
    
    /* Sidebar */
    [data-testid="stSidebar"] {
        background-color: #f0f4f8;
        border-right: 1px solid #dae1e7;
    }
    
    /* Success/Info Messages */
    .stSuccess, .stInfo {
        border-radius: 8px;
        font-size: 16px;
    }
</style>
""", unsafe_allow_html=True)

# --- Shared Configuration ---
def load_api_key():
    if os.path.exists("api_key.txt"):
        with open("api_key.txt", "r") as f:
            return f.read().strip()
    return ""

def save_api_key(key):
    with open("api_key.txt", "w") as f:
        f.write(key)

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuración")
    saved_key = load_api_key()
    api_key = st.text_input("Clave API de Gemini", value=saved_key, type="password")
    
    if st.button("Guardar Clave"):
        save_api_key(api_key)
        st.success("Guardada")
        
    st.divider()
    st.info("Carpetas de Salida:\n- `output/transcripts`\n- `output/notes`\n- `output/guides`")

if not api_key:
    st.warning("⚠️ Por favor ingresa tu API Key en la barra lateral para comenzar.")
    st.stop()

# Initialize Assistants
transcriber = Transcriber(api_key)
assistant = StudyAssistant(api_key)

# --- Tabs ---
tab1, tab2, tab3, tab4 = st.tabs([
    "📹 Transcriptor", 
    "📝 Apuntes Simples", 
    "🗺️ Guía de Estudio", 
    "🧠 Ayudante Quiz"
])

# --- Tab 1: Transcriptor ---
with tab1:
    st.header("1. Transcriptor de Videos")
    st.write("Sube los videos de tu unidad para procesarlos.")
    
    uploaded_files = st.file_uploader("Subir videos (.mp4, .mov)", type=['mp4', 'mov', 'avi'], accept_multiple_files=True)
    
    if st.button("Iniciar Transcripción", key="btn_transcribe"):
        if not uploaded_files:
            st.error("Sube un video primero.")
        elif not transcriber.check_ffmpeg():
            st.error("FFmpeg no encontrado.")
        else:
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Ensure folder exists
            out_dir = "output/transcripts"
            os.makedirs(out_dir, exist_ok=True)
            
            for i, uploaded_file in enumerate(uploaded_files):
                # Save temp video
                temp_video_path = uploaded_file.name
                with open(temp_video_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                
                def update_progress(msg, prog):
                    status_text.text(f"{uploaded_file.name}: {msg}")
                    batch_prog = (i + prog) / len(uploaded_files)
                    progress_bar.progress(min(batch_prog, 1.0))
                
                try:
                    # Process
                    txt_path = transcriber.process_video(temp_video_path, progress_callback=update_progress)
                    
                    # Move result to correct folder
                    final_path = os.path.join(out_dir, os.path.basename(txt_path))
                    if os.path.exists(final_path): os.remove(final_path)
                    os.rename(txt_path, final_path)
                    
                    st.success(f"✅ {uploaded_file.name} Transcrito -> {final_path}")
                    
                    # Read for download
                    with open(final_path, "r", encoding="utf-8") as f:
                        trans_text = f.read()

                    st.download_button(
                        label=f"⬇️ Descargar Transcripción (.txt)",
                        data=trans_text,
                        file_name=os.path.basename(final_path),
                        mime="text/plain"
                    )
                    
                except Exception as e:
                    st.error(f"Error: {e}")
                finally:
                    if os.path.exists(temp_video_path): os.remove(temp_video_path)
            
            progress_bar.progress(1.0)
            status_text.text("Proceso completado.")

# --- Helper to list transcripts ---
def get_transcripts():
    return glob.glob("output/transcripts/*.txt")

# --- Tab 2: Apuntes ---
with tab2:
    st.header("2. Generador de Apuntes Simples")
    transcripts = get_transcripts()
    
    if not transcripts:
        st.info("No hay transcripciones disponibles. Ve a la pestaña 1 para procesar videos.")
    else:
        selected_file = st.selectbox("Selecciona la unidad (transcripción):", transcripts, key="sel_notes")
        
        if st.button("✨ Generar Apuntes", key="btn_notes"):
            with st.spinner("Leyendo y resumiendo..."):
                with open(selected_file, "r", encoding="utf-8") as f:
                    text = f.read()
                
                notes = assistant.generate_notes(text)
                
                # Save as TXT
                base_name = os.path.basename(selected_file).replace(".txt", "")
                note_path = f"output/notes/Apuntes_{base_name}.txt"
                os.makedirs("output/notes", exist_ok=True)
                
                with open(note_path, "w", encoding="utf-8") as f:
                    f.write(notes)
                
                st.markdown(notes)
                st.success(f"Apuntes guardados en: {note_path}")
                st.download_button("Descargar Apuntes (.txt)", notes, file_name=f"Apuntes_{base_name}.txt", mime="text/plain")

# --- Tab 3: Guía ---
with tab3:
    st.header("3. Guía de Estudio Estratégica")
    transcripts = get_transcripts()
    
    if not transcripts:
        st.info("Primero necesitas transcripciones (Pestaña 1).")
    else:
        selected_file_guide = st.selectbox("Selecciona la unidad:", transcripts, key="sel_guide")
        
        if st.button("🗺️ Generar Guía de Estudio", key="btn_guide"):
            with st.spinner("Analizando estructura y claves de examen..."):
                with open(selected_file_guide, "r", encoding="utf-8") as f:
                    text = f.read()
                    
                guide = assistant.generate_study_guide(text)
                
                # Save as TXT
                base_name = os.path.basename(selected_file_guide).replace(".txt", "")
                guide_path = f"output/guides/Guia_{base_name}.txt"
                os.makedirs("output/guides", exist_ok=True)
                
                with open(guide_path, "w", encoding="utf-8") as f:
                    f.write(guide)
                
                st.markdown(guide)
                st.success(f"Guía guardada en: {guide_path}")
                st.download_button("Descargar Guía (.txt)", guide, file_name=f"Guia_{base_name}.txt", mime="text/plain")

# --- Tab 4: Quiz ---
with tab4:
    st.header("4. Ayudante de Pruebas")
    st.write("Sube una foto de una pregunta y la IA te dirá la respuesta correcta.")
    
    img_file = st.file_uploader("Sube imagen de la pregunta", type=['png', 'jpg', 'jpeg'])
    
    if img_file and st.button("🧠 Resolver Pregunta"):
        st.image(img_file, caption="Imagen subida", width=300)
        with st.spinner("Analizando pregunta..."):
            # Need to save temp image for PIL/Gemini maybe? 
            # Actually Gemini helper (study_assistant) takes path usually, let's adjust logic there or here.
            # We implemented study_assistant to take path. So save temp.
            temp_img_path = "temp_quiz_img.png"
            with open(temp_img_path, "wb") as f:
                f.write(img_file.getbuffer())
                
            answer = assistant.solve_quiz(temp_img_path)
            st.markdown(answer)
