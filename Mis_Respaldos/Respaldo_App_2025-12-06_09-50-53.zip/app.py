
import streamlit as st
import os
from transcriber import Transcriber

st.set_page_config(page_title="Transcriptor de Video", page_icon="🎥", layout="wide")

st.title("🎥 Transcriptor de Video a Texto")
st.markdown("Sube videos largos, y esta aplicación extraerá el audio, lo dividirá y lo transcribirá usando Google Gemini.")

# Function to load/save API key
def load_api_key():
    if os.path.exists("api_key.txt"):
        with open("api_key.txt", "r") as f:
            return f.read().strip()
    return ""

def save_api_key(key):
    with open("api_key.txt", "w") as f:
        f.write(key)

with st.sidebar:
    st.header("Configuración")
    
    # Auto-load key
    saved_key = load_api_key()
    api_key = st.text_input("Clave API de Gemini", value=saved_key, type="password", help="Obtén tu clave en Google AI Studio")
    
    if st.button("Guardar Clave API"):
        if api_key:
            save_api_key(api_key)
            st.success("¡Clave guardada!")
        else:
            st.warning("Escribe una clave para guardar.")

    if st.button("Verificar Conexión / Listar Modelos"):
        if not api_key:
            st.error("Primero ingresa la API Key")
        else:
            try:
                import google.generativeai as genai
                genai.configure(api_key=api_key)
                models = list(genai.list_models())
                names = [m.name for m in models if 'generateContent' in m.supported_generation_methods]
                st.success(f"¡Conexión Existosa! Modelos disponibles: {len(names)}")
                st.code("\n".join(names))
            except Exception as e:
                st.error(f"Error al conectar: {e}")

    st.info("Asegúrate de tener `ffmpeg` instalado en tu sistema.")

uploaded_files = st.file_uploader("Elige archivos de video", type=['mp4', 'mov', 'avi', 'mkv'], accept_multiple_files=True)

if st.button("Iniciar Transcripción"):
    if not api_key:
        st.error("Por favor, proporciona una clave API de Gemini.")
    elif not uploaded_files:
        st.error("Por favor, sube al menos un archivo de video.")
    else:
        # Auto-save key on start if not empty
        if api_key:
            save_api_key(api_key)

        transcriber = Transcriber(api_key)
        
        # Check ffmpeg first
        if not transcriber.check_ffmpeg():
            st.error("¡No se encontró FFmpeg! Por favor instálalo y agrégalo a tu PATH.")
            st.stop()
            
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        for i, uploaded_file in enumerate(uploaded_files):
            # Save uploaded file temporarily
            temp_video_path = uploaded_file.name
            with open(temp_video_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            
            st.subheader(f"Procesando: {uploaded_file.name}")
            
            def update_progress(msg, prog):
                status_text.text(f"{uploaded_file.name}: {msg}")
                # Scale progress to overall batch
                batch_prog = (i + prog) / len(uploaded_files)
                progress_bar.progress(min(batch_prog, 1.0))
            
            try:
                output_file = transcriber.process_video(temp_video_path, progress_callback=update_progress)
                st.success(f"¡Terminado {uploaded_file.name}! Guardado en {output_file}")
                
                with open(output_file, "r", encoding="utf-8") as f:
                    transcript_text = f.read()
                    
                st.download_button(
                    label=f"Descargar Transcripción de {uploaded_file.name}",
                    data=transcript_text,
                    file_name=output_file,
                    mime="text/plain"
                )
                
            except Exception as e:
                st.error(f"Error procesando {uploaded_file.name}: {str(e)}")
            finally:
                # Cleanup video
                if os.path.exists(temp_video_path):
                    os.remove(temp_video_path)
                    
        progress_bar.progress(1.0)
        status_text.text("¡Todos los archivos procesados!")
