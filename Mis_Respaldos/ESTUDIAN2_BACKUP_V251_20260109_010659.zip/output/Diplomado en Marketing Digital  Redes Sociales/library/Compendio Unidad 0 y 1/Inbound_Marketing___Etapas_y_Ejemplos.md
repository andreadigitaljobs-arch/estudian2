➡️ Un desconocido te visita.

Ejemplo de vida:
Es como cuando buscas “cómo bajar la panza” y te gusta un video que te explica bien. Esa marca ya te atrajo.

2️⃣ CONVERTIR — Transformas visitas en contactos

¿Cómo?

Formularios

Landing pages

Un ebook gratis: “Guía de cafeteras 2025”

CTA: “Descárgala aquí”

Qué logras:
➡️ Ahora ya tienes el dato de la persona. Ya no es un visitante, es un lead.

Ejemplo de vida:
Es como cuando tú sigues una cuenta porque te encantó cómo explica. Ya dejaste de ser visitante; ahora te uniste.

3️⃣ CERRAR — Convencerlos de comprar

¿Cómo se hace?

Email marketing

Automatizaciones (workflows)

CRM

Recordatorios

“¿Aún quieres tu cafetera? Mira esta oferta”

Qué logras:
➡️ Ese lead te compra.

Ejemplo de vida:
Cuando entras a MercadoLibre varias veces a ver el mismo producto y luego te llega: “¡Aún está disponible!”. Y dices… bueno sí.

4️⃣ DELEITAR — Hacer que AMEN tu marca

¿Cómo?

Mensajes post-compra

Tips de uso

Reels con trucos

Acceso a comunidad

Beneficios exclusivos

Qué logras:
➡️ Se convierte en fan → te recomienda → atrae nuevos clientes.

Ejemplo de vida:
Cuando compras algo y el vendedor te habla después para ayudarte sin pedirte nada. Lo recomiendas porque te trataron mejor que otras marcas.

🌈 LO QUE TIENES QUE RECORDAR (ASÍ NO SE TE OLVIDA)
⭐ Inbound = atraer
⭐ Outbound = interrumpir
⭐ Inbound son 4 pasos: atraer → convertir → cerrar → deleitar
⭐ Todo se logra creando contenido útil
⭐ El objetivo final es fidelizar: que tus clientes se vuelvan promotores