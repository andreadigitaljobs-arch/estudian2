Pregunta 4

Correcta: Option 3
✔ Ciclos de retroalimentación = acción → datos → ajustes → repetir. IA acelera este proceso.

Pregunta 5

Correcta: Option 3
✔ La importancia está en permitir ajustes continuos basados en feedback para mejorar resultados.