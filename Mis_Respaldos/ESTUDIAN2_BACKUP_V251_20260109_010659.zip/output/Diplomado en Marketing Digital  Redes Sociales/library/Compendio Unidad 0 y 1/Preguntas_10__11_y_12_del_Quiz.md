Pregunta 10

Respuesta correcta:
✅ Todas las anteriores

Pregunta 11

Respuesta correcta:
✅ Cada negocio requiere definir estrategias de marketing de forma personalizada y particular, dependiendo de la audiencia, objetivo y misión.

Pregunta 12

Respuesta correcta:
✅ Es cuando las metas del cliente se sobreponen o se alinean con las del negocio.