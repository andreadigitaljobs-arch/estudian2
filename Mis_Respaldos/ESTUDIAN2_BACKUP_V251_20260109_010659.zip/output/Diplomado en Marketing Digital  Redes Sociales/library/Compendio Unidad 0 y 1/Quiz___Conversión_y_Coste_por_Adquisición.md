Perfecto, aquí van las respuestas claras y seguras para estas dos preguntas:

Question 7

Es el término usado para indicar cuando un usuario ha completado la meta (compra, descarga, suscripción…).

✅ Respuesta: Conversión

Question 8

Es el coste total invertido en promocionar un sitio web para conseguir una venta.

✅ Respuesta: Coste por adquisición

Si quieres seguimos con las siguientes.