**Pregunta 1:**
Respuesta correcta: Option 1
✔ Psicografía. La IA ayuda analizando datos para identificar grupos naturales con intereses y comportamientos comunes.

**Pregunta 2:**
Respuesta correcta: Option 4
✔ Tomar un amplio mercado objetivo y dividirlo en grupos más pequeños y manejables con cosas en común.

**Pregunta 3:**
Respuesta correcta: Option 2
✔ Estilo de vida, valores, intereses y actitudes (Psicografía).

**Pregunta 4:**
Respuesta correcta: Option 4
✔ Analizando datos para identificar grupos naturales con intereses comunes y patrones de comportamiento.

**Pregunta 5:**
Respuesta correcta: Option 4
✔ Crear mensajes muy específicos para segmentos enfocados, haciendo el marketing más efectivo.

**Lista rápida:**
Pregunta | Respuesta
------- | --------
1       | Option 1
2       | Option 4
3       | Option 2
4       | Option 4
5       | Option 4