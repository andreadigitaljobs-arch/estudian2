Perfecto, aquí la clave es recordar las cuatro etapas oficiales del inbound marketing:

Atraer → Convertir → Cerrar → Deleitar

Ahora, revisemos tus opciones:

Primera opción del quiz:

Contactar – Atraer

Proporcionar Contenido

Transacción Final

Fidelización

Esta opción sí coincide con la estructura del inbound:

Contactar/Atraer → Atraer

Proporcionar contenido → Convertir

Transacción final → Cerrar

Fidelización → Deleitar

Segunda opción:

Proporcionar contenido

Transacción final

Fideliza

Control

❌ No incluye la parte de atraer, ni coincide con las 4 fases.

✅ RESPUESTA CORRECTA: LA PRIMERA OPCIÓN