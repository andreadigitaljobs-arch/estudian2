Pregunta 4

Correcta: Porque compara opciones y pide recomendaciones.

Pregunta 5

Correcta: Pagados, controlados y ganados.

Pregunta 6

Correcta: Google Adwords.