Aquí la pregunta está conectada directamente con esto que dijo el video:

“Al usar IA y datos de primera mano puedes descubrir qué resuena con tu audiencia y diseñar estrategias pagas para capturar nuevas personas increíblemente similares.”

Así que no hay duda:

❗La respuesta correcta es: Option 4 (D)

“Diseñar estrategias pagas para capturar nuevas personas increíblemente similares a la audiencia existente.”

Eso es EXACTAMENTE lo que explica el video como "la mejora".

Marca D.