Aquí te doy todas rápidas y seguras, basadas exactamente en el contenido del video que me pasaste:

Pregunta 1

Correcta: Option 2
✔ Trabajar en ciclos rápidos + IA como socio de investigación para refinar ideas sin esperar información perfecta.

Pregunta 2

Correcta: Option 4
✔ Ciclos rápidos de planificación, ejecución, aprendizaje y adaptación = esencia del marketing ágil.

Pregunta 3

Correcta: Option 1
✔ IA como socio de investigación y entrenamiento que te ayuda a refinar pensamiento rápidamente.

Pregunta 4

Correcta: Option 3
✔ Ciclos de retroalimentación = acción → datos → ajustes → repetir. IA acelera este proceso.

Pregunta 5

Correcta: Option 3
✔ La importancia está en permitir ajustes continuos basados en feedback para mejorar resultados.