Perfecto, aquí es Inbound, así que piensa en todo lo que atrae, no interrumpe y se hace con permiso del usuario.

✔ Recursos típicos del INBOUND:

Campañas de email marketing (cuando son segmentadas y basadas en suscripción, NO masivas)

Llamados a la acción (CTA) → súper inbound, clave para convertir

❌ Lo que NO pertenece al inbound:

Anuncios por TV y Radio → outbound

Vallas publicitarias → outbound

✅ RESPUESTA CORRECTA:

Campañas de email marketing + Llamados a la acción