Vamos directo y rápido — sin adornos, sin perder tiempo:

Pregunta 3

Cuando un visitante entra a nuestro sitio web y sale después de una sola página, eso es:
✔ Tasa de Rebote

Pregunta 4

Cuando un visitante no completa la acción que queríamos (compra, registro, etc.):
✔ Abandono

Cuando estés lista, seguimos con la 5.