Perfecto, esta es de selección múltiple.
Y la clave es identificar solo las oportunidades reales del marketing online, NO cosas físicas ni de tiendas.

Las correctas son:

✅ Ofrecer publicidad orientada a las preferencias de tus clientes.
(Esto es 100% digital, segmentación → oportunidad real.)

❌ Ofrecer una amplia gama de productos nuevos en anaqueles físicos.
(Eso es de tiendas físicas → NO aplica.)

❌ Mayor rotación en los almacenes mediante nuevos vendedores.
(Nada que ver con marketing online → NO aplica.)

✅ Conocer lo que les agrada a tus clientes a través de sus Likes.
(Claro, datos digitales → oportunidad real.)

✅ Lograr llegar a un mayor número de clientes nuevos a través de la red online.
(Este ES uno de los beneficios principales.)

✅ Poder ofrecer ventas en línea a través de su sitio web.
(También es una oportunidad clave.)

RESPUESTAS CORRECTAS:
✔ 1
✔ 4
✔ 5
✔ 6