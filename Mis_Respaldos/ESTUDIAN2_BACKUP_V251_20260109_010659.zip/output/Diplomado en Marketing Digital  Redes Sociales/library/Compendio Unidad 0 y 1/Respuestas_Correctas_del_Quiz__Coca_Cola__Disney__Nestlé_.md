**Pregunta 1 — Coca-Cola (Identifica la visión)**

✔ Refrescar al mundo, inspirar momentos de optimismo y felicidad, creando valor marcando la diferencia.

**Pregunta 2 — Coca-Cola (Identifica la misión)**

✔ Bebidas: Ofrecer una variada cartera de productos de calidad que se anticipen y satisfagan los deseos y necesidades de los consumidores.
Personas: Ser un buen lugar donde trabajar, que las personas se sientan inspiradas para dar cada día lo mejor de sí mismas.

**Pregunta 3 — Coca-Cola (Identifica los valores)**

✔ Liderazgo, Colaboración, Integridad, Rendición de cuentas, Pasión, Diversidad, Calidad.

**Pregunta 4 — Disney (Identifica los valores)**

✔ Calidad, Comunidad, Historia, Optimismo, Decencia.

(corresponde a la lista larga de valores de Disney)

**Pregunta 5 — Disney (Identifica la misión)**

✔ Crear felicidad proporcionando el mejor entretenimiento a personas de todas las edades y en todos los lugares del mundo.

**Pregunta 6 — Disney (Identifica la visión)**

✔ Lo que este país realmente necesita es un lugar donde las familias puedan ir con sus hijos a divertirse... (el texto del parque limpio y trato de primera clase).

(Es el párrafo larguísimo que comienza con “Lo que este país realmente necesita…”)

**Pregunta 7 — Nestlé (Identifica la visión)**

✔ Evolucionar de una respetada y confiable compañía de alimentos a una respetada y confiable compañía de alimentos, nutrición, salud y bienestar.

**Pregunta 8 — Nestlé (Identifica la misión)**

✔ Exceder con servicios, productos y marcas, las expectativas de Nutrición, Salud y Bienestar de nuestros clientes y consumidores.

**Pregunta 9 — Nestlé (Identifica los valores)**

✔ La lista larga:
Fuerte compromiso con productos y marcas de calidad; respeto de otras culturas y tradiciones; relaciones personales basadas en la confianza; apertura y curiosidad; rendición de cuentas; orgullo de contribuir; lealtad a la compañía; etc.