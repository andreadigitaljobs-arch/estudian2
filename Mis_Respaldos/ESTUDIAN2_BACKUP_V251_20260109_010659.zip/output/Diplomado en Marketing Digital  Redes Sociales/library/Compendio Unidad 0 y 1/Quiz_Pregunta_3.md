Esta también es directa del video.

❗La respuesta correcta es: Option 4 (D)

Porque el video dijo literalmente:

“Los medios propios son canales sobre los que tienes control directo.”

Las otras opciones corresponden a:

A = medios pagados

B = datos de terceros (no aplica)

C = medios ganados

Así que marca Option 4 (D).