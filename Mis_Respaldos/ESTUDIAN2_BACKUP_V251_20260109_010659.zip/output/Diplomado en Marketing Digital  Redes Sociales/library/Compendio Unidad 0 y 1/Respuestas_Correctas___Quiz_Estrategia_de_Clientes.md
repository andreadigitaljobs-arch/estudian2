*   **Pregunta 1:** Alcanzar, entender y encontrar a la audiencia adecuada.
*   **Pregunta 2:** Aquel segmento de clientes dentro de un mercado, al que voy a dirigir mis anuncios.
*   **Pregunta 3:** La audiencia digital te permite buscarla, medirla y analizarla.
*   **Pregunta 4:** Es el segmento de mercado, de todo un universo, al cual le interesa el producto / servicio que ofreces.
*   **Pregunta 5:** Son los elementos que desea conseguir la audiencia a través de una oferta de valor.
*   **Pregunta 6:** A los medios digitales que la audiencia utiliza con más frecuencia.
*   **Pregunta 7:** Es una medida del nivel del rendimiento de un proceso.
*   **Pregunta 8:** Para controlar y medir los KPIs.
*   **Pregunta 9:** A través de alinear las metas del negocio con las metas del cliente.