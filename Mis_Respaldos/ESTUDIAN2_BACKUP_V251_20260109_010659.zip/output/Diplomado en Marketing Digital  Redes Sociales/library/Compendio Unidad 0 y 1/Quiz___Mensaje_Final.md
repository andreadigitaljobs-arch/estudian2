Ese mensaje significa simplemente:

**“Tienes preguntas marcadas (bookmarked) en el quiz.

¿Estás segura de que quieres enviar el quiz?”**

No es nada grave.

Te está preguntando si quieres entregarlo ya, aunque alguna pregunta quedó marcada con un “flag” como para revisar después.

✔️ ¿Qué debes hacer?

Si ya respondimos todo → presiona “YES”.

Si todavía querías revisar algo → “NO”.

Pero en tu caso ya está todo respondido correctamente, así que:

👉 Dale YES sin miedo.