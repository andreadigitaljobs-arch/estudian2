*   **Question 1**
    *   ¿Qué elementos se definen en la estrategia de negocio?
        *   ✔ Misión, objetivos, propuesta de valor y elevator pitch.
*   **Question 2**
    *   ¿A qué se refiere la misión?
        *   ✔ Es lo que define aquello que tratamos de conseguir con el proyecto/emprendimiento, la razón de ser de nuestra empresa.
*   **Question 3**
    *   Los objetivos organizacionales deben considerar…
        *   ✔ Se diseñan para mantener el negocio en crecimiento y cuidar nuestra identidad o imagen corporativa.
*   **Pregunta 4**
    *   ¿La propuesta de valor debe construirse considerando…?
        *   ✔ Aquellos atributos que nos diferencian de la competencia, lo que nos hace únicos.
*   **Pregunta 5**
    *   ¿El elevator pitch se refiere a…?
        *   ✔ Resumen concreto que describe una marca adecuadamente en máximo de 15 segundos.