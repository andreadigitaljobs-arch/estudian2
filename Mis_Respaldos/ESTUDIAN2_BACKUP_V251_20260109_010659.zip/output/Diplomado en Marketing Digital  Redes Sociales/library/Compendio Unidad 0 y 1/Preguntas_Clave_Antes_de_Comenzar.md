Se requiere que el usuario responda:

1.  ¿Cuál será tu caso de estudio del diplomado?
2.  ¿Quieres que tus apuntes del primer módulo los genere yo desde cero o tú los copias y yo los ordeno?
3.  ¿Cuándo será tu primer bloque de estudio hoy? (hora exacta)

El tutor actuará como espejo, exigiendo enfoque y evitando la pérdida de tiempo.