Perfecto, vamos sin dudarlo:

✔ La respuesta correcta es: Llamados a la acción

Porque la pregunta habla de botones + verbos imperativos (Compra, Descarga, Ahorra, Regístrate), y eso es exactamente lo que define a un CTA.