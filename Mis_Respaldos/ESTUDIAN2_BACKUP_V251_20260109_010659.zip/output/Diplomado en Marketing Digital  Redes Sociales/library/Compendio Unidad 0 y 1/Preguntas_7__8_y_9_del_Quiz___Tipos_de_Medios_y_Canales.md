Pregunta 7

¿Cuál de los siguientes medios es del tipo “controlados”?

Opciones:

Facebook Ads

Displays

Sitio web de tu empresa

👉 Respuesta correcta: Sitio web de tu empresa
(Porque es un medio que tú controlas completamente: diseño, contenido, estructura).

Pregunta 8

¿Cuál de los siguientes medios es del tipo “ganados”?

Opciones:

Lista de clientes

Blog corporativo

Cuentas en RSSS

👉 Respuesta correcta: Cuentas en RSSS
(Ganados = menciones, seguidores, comentarios, reseñas, interacción orgánica. Nada pagado ni propio.)

Pregunta 9

¿Cuáles de estos son “canales”?

Opciones:

Medios pagados y ganados

Redes sociales (Facebook, Instagram, LinkedIn), mail marketing, displays

Medios controlados, ganados y pagados

👉 Respuesta correcta: Redes sociales (Facebook, Instagram, LinkedIn), mail marketing, displays
(Es la única opción que menciona canales reales, no clasificaciones de medios.)