La metodología de Inbound Marketing siempre sigue estas 4 fases, en este orden:

👉 Atraer
👉 Convertir
👉 Cerrar
👉 Deleitar

Justo como lo explica el video.

✅ RESPUESTA CORRECTA:

Atraer – Convertir – Cerrar – Deleitar

Marca la primera opción.