*   ¿Qué es marketing digital?
Promoción de un negocio en línea usando canales digitales para captar al cliente en el momento adecuado.
*   ¿Qué elementos cambiaron el proceso de compra?
Internet + tecnología móvil.
*   Nombra los tres tipos de medios:
Pagados, controlados y ganados.
*   Ejemplos de medios pagados / controlados / ganados.
Aquí respondes exactamente como el video lo dijo.
*   Por qué el cliente ahora está a cargo del proceso de compra.
Por la capacidad de investigar, comparar, pedir recomendaciones y leer reseñas.
*   Qué medios tradicionales han sido desplazados.
Impreso, TV por cable, radio, páginas amarillas.