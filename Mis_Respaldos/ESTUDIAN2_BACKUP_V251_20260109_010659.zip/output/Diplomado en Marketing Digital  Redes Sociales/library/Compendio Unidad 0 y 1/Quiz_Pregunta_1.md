Andrea, esta está facilísima porque coincide EXACTO con lo que dijo el video:

❗ La correcta es la Option 2 (B).

Porque:

Medios Ganados = cuando otras personas hablan de ti orgánicamente.

Medios Pagados se vuelven más efectivos gracias a IA + datos de primera mano para encontrar audiencias similares.

Es la definición literal del video 2.

Marca Option 2 (B).