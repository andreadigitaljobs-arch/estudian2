Qué medios tradicionales han sido desplazados:
Impreso, TV por cable, radio, páginas amarillas.