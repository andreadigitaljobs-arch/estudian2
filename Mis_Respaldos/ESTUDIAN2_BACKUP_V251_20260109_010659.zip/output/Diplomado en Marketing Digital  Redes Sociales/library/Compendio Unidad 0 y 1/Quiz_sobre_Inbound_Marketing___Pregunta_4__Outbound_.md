Perfecto, aquí solo te están pidiendo los recursos que pertenecen al OUTBOUND marketing, es decir:
lo tradicional, lo que interrumpe, lo que empuja el mensaje.

✔ Recursos típicos del OUTBOUND:

Emails masivos (bombardeo, no segmentados)

Vallas publicitarias (publicidad tradicional intrusiva)

❌ Recursos que NO son outbound:

Llamadas a la acción → son inbound

SEO → inbound

✅ RESPUESTA CORRECTA:

Email masivos + Vallas publicitarias