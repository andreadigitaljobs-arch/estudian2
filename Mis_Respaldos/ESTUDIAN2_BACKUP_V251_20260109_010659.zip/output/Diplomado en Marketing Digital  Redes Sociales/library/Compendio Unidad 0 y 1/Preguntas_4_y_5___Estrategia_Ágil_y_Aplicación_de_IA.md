Question 4

¿Qué permite a una estrategia ágil transformar el marketing de un "monólogo" en una "conversación"?

✅ Option 1: Construir activamente bucles de retroalimentación (feedback loops).

Question 5

¿Qué ejemplo de aplicación de IA se menciona para obtener retroalimentación procesable inmediata en horas en lugar de semanas?

La que corresponde exactamente al video es:

✅ Option 3: Usar herramientas de IA para probar rápidamente diferentes titulares de anuncios y ver cuál obtiene más clics.