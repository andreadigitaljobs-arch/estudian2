Se propone un orden para aprobar el diplomado más rápido:

- **Semana 1-2:** Fundamentos (módulos 1 y 2) - El tutor convierte los videos en apuntes condensados.
- **Semana 3:** Entrega 1 - Plan de marketing sección 1
- **Semana 4-5:** Modelo Canvas + análisis estratégico - Entrega 2 - Modelo Canvas
- **Semana 6:** Plan de social media + presupuesto - Entrega 3 - Plan estratégico de social media
- **Semana 7:** Calendario editorial - Entrega 4 - Calendario editorial
- **Semana 8-10:** Sitio web + canales digitales - Entrega 5 - Canales digitales y web
- **Semana 11-12:** Email marketing - Entrega 6 - Campaña de email marketing
- **Semana 13-17:** SEO / SEM / Analytics + Proyecto final - Entrega 7 - Proyecto final + defensa

El tutor guiará en cada entrega.