Esta también es directa y literal del video.

❗La respuesta correcta es: Option 1 (A)

Porque:

Medios Pagados = “pagar para difundir su mensaje”.

Y el ejemplo exacto del video fue: pagarle a un influencer para que hable de tu producto.

Las otras opciones son:

B = medios propios

C = medios ganados

D = datos propios (medios propios)

Así que marca Option 1 (A).