Pregunta 9

¿Cuáles de estos son “canales”?

Opciones:

Medios pagados y ganados

Redes sociales (Facebook, Instagram, LinkedIn), mail marketing, displays

Medios controlados, ganados y pagados

👉 Respuesta correcta: Redes sociales (Facebook, Instagram, LinkedIn), mail marketing, displays
(Es la única opción que menciona canales reales, no clasificaciones de medios.)

Pregunta 10

Respuesta correcta:
✅ Todas las anteriores

Pregunta 11

Respuesta correcta:
✅ Cada negocio requiere definir estrategias de marketing de forma personalizada y particular, dependiendo de la audiencia, objetivo y misión.

Pregunta 12

Respuesta correcta:
✅ Es cuando las metas del cliente se sobreponen o se alinean con las del negocio.

Pregunta 13

Respuesta correcta:
✅ Comercialización de una experiencia.