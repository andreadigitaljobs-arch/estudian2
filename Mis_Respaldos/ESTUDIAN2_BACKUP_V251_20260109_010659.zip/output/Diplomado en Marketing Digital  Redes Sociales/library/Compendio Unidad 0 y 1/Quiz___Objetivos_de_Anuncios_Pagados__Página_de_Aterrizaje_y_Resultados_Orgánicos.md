Perfecto, Andrea. Vamos una por una, directo y sin perder tiempo.

Pregunta 9

El objetivo de los anuncios pagados es:
➡️ Lograr que los costes de adquisición sean menores al Valor de tiempo de vida

(Lo dice literalmente el video: los anuncios solo tienen sentido si el CPA es menor al LTV.)

Pregunta 10

El sitio al cual redireccionamos a los usuarios después del clic:
➡️ Página de aterrizaje

(Una landing page específica para la promoción.)

Pregunta 11

Resultados obtenidos sin ser pagados, gracias al SEO:
➡️ Resultados orgánicos

—

Cuando estés lista, seguimos con el siguiente módulo ✨