Las tablas son estructuras fijas que deben usarse tal cual para evitar errores.

**1) Estrategia del Cliente – Tabla Principal:**

*   A. Nombre del negocio.
*   B. Declaración de misión (enfocada en el cliente).
*   C. Público objetivo (3 segmentos: Edad, Género, Interés principal).
*   D. Metas de la audiencia (metas del cliente).
*   E. Tecnología de la audiencia (dónde encontrarlos).

**2) Segmentación Avanzada por Audiencia (Tabla Profunda):**

*   Cada público objetivo tiene su mini-tabla con:
    *   Objetivo del negocio para ese segmento.
    *   Valor compartido.
    *   KPI.
    *   Meta cuantificable.