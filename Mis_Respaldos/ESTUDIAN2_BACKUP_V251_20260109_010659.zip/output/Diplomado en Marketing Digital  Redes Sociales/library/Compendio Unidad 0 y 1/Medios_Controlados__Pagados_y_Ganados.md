Tus medios controlados serán:
tu IG, tu web, tu comunidad, tus correos, tu página de ventas.

Tus medios pagados (cuando lleguemos al módulo) serían:
Meta Ads o Google Ads si lo deseas.

Tus medios ganados:
reseñas, recomendaciones, reposts de alumnos, artículos, menciones.

Y desde aquí se arma el plan de marketing inicial.