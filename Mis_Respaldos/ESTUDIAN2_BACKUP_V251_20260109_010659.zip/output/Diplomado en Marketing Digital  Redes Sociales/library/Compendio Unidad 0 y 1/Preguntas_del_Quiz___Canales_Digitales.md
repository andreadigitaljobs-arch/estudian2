Pregunta 1

¿A qué se refieren los canales digitales?
✅ A los medios de comunicación digitales como buscadores, correo electrónicos, anuncios.

Pregunta 2

¿Qué tipos de canales existen en el marketing digital?
✅ Canales sociales, de búsquedas, display, email.

Pregunta 3

¿Para qué usamos los canales digitales?
✅ Para capturar y atraer la atención de nuestros clientes potenciales, en el lugar y momento adecuado.