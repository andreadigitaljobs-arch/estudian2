Vamos rápido y seguro 💪

Pregunta 5

“Es el término utilizado para medir las veces que los usuarios han visto nuestro anuncio pagado.”

👉 Respuesta correcta: Impresiones

Pregunta 6

“La cantidad de veces que un usuario ha visto nuestro anuncio se denomina:”

👉 Respuesta correcta: Frecuencia

Porque:

Impresiones = número total de veces que se mostró el anuncio.

Frecuencia = cuántas veces, en promedio, cada usuario lo vio.

Listo, seguimos con las demás cuando quieras.