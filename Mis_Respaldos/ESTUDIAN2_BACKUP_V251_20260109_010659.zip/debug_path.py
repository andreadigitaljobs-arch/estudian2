
import sys
import streamlit as st
print(f"PYTHON_PATH: {sys.executable}")
st.write(f"PYTHON_PATH: {sys.executable}")
