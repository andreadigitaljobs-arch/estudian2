import os
import shutil
import zipfile
from datetime import datetime

def create_safe_backup():
    cwd = os.getcwd()
    backup_name = f"ESTUDIAN2_BACKUP_V251_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    backup_dir = os.path.join(cwd, "Mis_Respaldos")
    os.makedirs(backup_dir, exist_ok=True)
    
    zip_path = os.path.join(backup_dir, backup_name)
    
    # Files/Dirs to ignore
    ignore_list = {
        '.git', 
        '__pycache__', 
        '.streamlit/secrets.toml', 
        '.env', 
        'api_key.txt', 
        'Mis_Respaldos',
        'venv',
        '.devcontainer'
    }
    
    ignore_extensions = {'.wav', '.mp4'}
    ignore_prefixes = {'temp_', 'ESTUDIAN2_BACKUP_'}

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(cwd):
            # Prune directories
            dirs[:] = [d for d in dirs if d not in ignore_list and not d.startswith('.')]
            
            for file in files:
                rel_path = os.path.relpath(os.path.join(root, file), cwd)
                
                # Check exclusions
                should_ignore = False
                if rel_path in ignore_list: should_ignore = True
                if any(rel_path.endswith(ext) for ext in ignore_extensions): should_ignore = True
                if any(file.startswith(pre) for pre in ignore_prefixes): should_ignore = True
                
                if not should_ignore:
                    print(f"Adding: {rel_path}")
                    zipf.write(os.path.join(root, file), rel_path)
    
    return zip_path

if __name__ == "__main__":
    path = create_safe_backup()
    print(f"\nSUCCESS: Backup created at {path}")
